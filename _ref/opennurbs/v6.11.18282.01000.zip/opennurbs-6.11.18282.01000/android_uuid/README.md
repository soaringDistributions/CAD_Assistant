uuid support files for Android build of openNURBS

source initially from
https://android.googlesource.com/platform/external/e2fsprogs
